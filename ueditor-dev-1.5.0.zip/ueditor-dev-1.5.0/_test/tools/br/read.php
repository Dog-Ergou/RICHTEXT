<?php
/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 12-9-25
 * Time: 下午3:15
 * To change this template use File | Settings | File Templates.
 */
//echo $_POST['name'];
echo file_get_contents($_POST['name']);
//echo file_get_contents('test.txt');
?>