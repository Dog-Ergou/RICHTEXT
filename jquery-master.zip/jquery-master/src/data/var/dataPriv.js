import Data from "../Data.js";

export default new Data();
